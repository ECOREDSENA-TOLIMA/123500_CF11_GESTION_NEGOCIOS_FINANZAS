function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5u5l2fIBEmf":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

